<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First PHP Script</title>
</head>
<body>
    <?php
    echo "This is my first PHP Script.<br>";
    echo "This is my first PHP Script.<br>";
    echo "This is my first PHP Script.<br>";
    echo "This is my first PHP Script.<br>";
    echo "This is my first PHP Script.<br>";
    echo "This is my first PHP Script.<br>";
    echo "This is my first PHP Script.<br>";
    echo "This is my first PHP Script.<br>";
    echo "This is my first PHP Script.";
    ?>
    

</body>
</html>
