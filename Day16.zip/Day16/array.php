<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First PHP Script</title>
</head>
<body>
    
    <?php
    $cars = array("Chayan","Dhruvi","Dhruvil");
    echo "<br>";
    var_dump($cars);
    echo "<br>";
    echo $cars[0];
    echo $cars[1];
    echo $cars[2];

    
    ?>
    
    

</body>
</html>
