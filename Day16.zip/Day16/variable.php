<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>First PHP Script</title>
</head>
<body>
    <?php
    $name = "Rohan Movaliya";
    $number = 25;
    $num = 10.5;

    echo $name;
    echo "<br>";
    echo $number;
    echo "<br>";
    echo $num;
    ?>
    

</body>
</html>
